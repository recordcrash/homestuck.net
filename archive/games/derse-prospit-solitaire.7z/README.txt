README by Makin + geminineedle

This is a mod for the Windows Solitaire (up to Windows 7).

"To install the file, simply replace both the “cards.dll” files in your WINDOWS/system32 folder and in the dllcache with the file provided. You may want to make a backup of the original cards.dll in a different folder in case you want to switch back to the default windows deck."