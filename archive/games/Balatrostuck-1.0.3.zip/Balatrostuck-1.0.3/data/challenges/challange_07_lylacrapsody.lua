SMODS.Challenge{
    key = "lylacrapsody",
    loc_txt = {
        name = "Mail from Ly'Lac",
    },
    rules = { 
        custom = {
            {id = 'lylac1'},
            {id = 'lylac2'}
        },
    },
    jokers = {
        --[[
    { 
        id = "",
        edition = "",
        eternal = false,
        pinned = false

    }
        --]]
    },
    consumeables = {
        --[[
    { 
        id = "",
        edition = "",
        eternal = false,

    }
        ]]
    },
    vouchers  = { --[[
    { 
        id = "",
    
    } 
        ]]
    },
    restrictions = { --[[
        restrictions.banned_cards = {},
        restrictions.banned_tags = {},
        restrictions.banned_other = {},
    ]]
    }
}