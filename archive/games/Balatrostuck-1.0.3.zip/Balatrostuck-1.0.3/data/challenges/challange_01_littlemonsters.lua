SMODS.Challenge{
    key = "littlemonsters",
    loc_txt = {
        name = "Little Monsters",
    },
    rules = { 
        modifiers = {
            {id = 'discards', value = 1}
        } 
    },
    jokers = {
          { 
        id = "j_bstuck_applejuice",
        eternal = false,
        pinned = false

    },
    { 
        id = "j_bstuck_applejuice",
        eternal = false,
        pinned = false

    },
    { 
        id = "j_bstuck_applejuice",
        eternal = false,
        pinned = false

    },
    { 
        id = "j_bstuck_applejuice",
        eternal = false,
        pinned = false

    },
    { 
        id = "j_bstuck_applejuice",
        eternal = false,
        pinned = false

    }
    },
    consumeables = {
        --[[
    { 
        id = "",
        edition = "",
        eternal = false,

    }
        ]]
    },
    vouchers  = { --[[
    { 
        id = "",
    
    } 
        ]]
    },
    restrictions = { 
      banned_cards = {
         {id = "j_merry_andy"}, 
          {id = "j_drunkard"},
          {id = "v_wasteful"}
      }
    }
}