SMODS.Challenge{
    key = "likeaseer",
    loc_txt = {
        name = "Like A Seer",
    },
    rules = {  
        custom = {
            {id = 'tripleblindsize'},
        },
    },
    jokers = {
        { 
        id = "j_bstuck_cloudwatching",
        eternal = false,
        pinned = false
    },
    { 
        id = "j_trio",
        eternal = false,
        pinned = false
    }
    },
    consumeables = {
        --[[
    { 
        id = "",
        edition = "",
        eternal = false,

    }
        ]]
    },
    vouchers  = { --[[
    { 
        id = "",
    
    } 
        ]]
    },
    restrictions = { --[[
        restrictions.banned_cards = {},
        restrictions.banned_tags = {},
        restrictions.banned_other = {},
    ]]
    }
}