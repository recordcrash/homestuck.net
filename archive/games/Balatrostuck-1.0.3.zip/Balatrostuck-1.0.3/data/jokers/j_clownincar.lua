function Balatrostuck.INIT.Jokers.j_clownincar()
    SMODS.Joker{
        name = "Clown In Car",
        key = "clownincar",
        config = {
            extra = {
            }
        },
        loc_txt = {
            ['name'] = 'Clown In Car',
            ['text'] = {
                [1] = "{C:attention}Playing cards{} in {C:attention}Standard Packs{} can",
                [2] = "only be the ranks corresponding",
                [3] = "to held {C:attention}Zodiac Cards{} (if any)"
            },
            unlock = {'Unlocked by',
            'finishing Act 2'}
        },
        pos = {
            x = 3,
            y = 11
         },
         loc_vars = function(self, info_queue, card)
            art_credit('garb', info_queue)
            return {vars = {}}
        end,
        cost = 4,
        rarity = 2,
        blueprint_compat = false,
        eternal_compat = true,
        unlocked = false,
        atlas = 'HomestuckJokers',
        loc_vars = function(self, info_queue, card)
            art_credit('garb', info_queue)
            return {vars = {}}
        end,
        check_for_unlock = function(self,args)
            if args.type == 'bstuck_ascend' then
                unlock_card(self)
            end
        end
    }
end 