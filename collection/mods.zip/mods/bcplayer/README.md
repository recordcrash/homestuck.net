# bcplayer

This is a proof-of-concept in-app music player, and a demonstration of the modding toolbar API.

The player will randomly shuffle all non-spoiler Homestuck music. You can open the player with the music icon browser action and you can close the player with the carat.

To install, save the tuhc-bcplayer *folder* to your mods directory.
