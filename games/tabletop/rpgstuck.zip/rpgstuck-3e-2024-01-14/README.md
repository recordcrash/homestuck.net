# RPGStuck

## Introduction

RPGStuck 3e is the third edition of a fanmade Homestuck tabletop game. As of 2024-01-14, RPGStuck has an active Discord community with over 1700 members. This folder contains the most recent update of RPGStuck 3e as of 2024-01-14.

Starting as a hack of Dungeons and Dragons, RPGStuck has since grown into its own fully-fledged system, taking influence from various sources including Lancer, Blades in the Dark, and Shadow of the Demon Lord. The system has many features directly inspired by various SBURB mechanics, such as alchemy, fraymotifs, housebuilding, and god-tier powers. It often takes a "toolbox" approach in order to help players build customizable, powerful, and always viable characters. Rather than punishing non-optimal builds, RPGStuck encourages creativity in its players with a system balanced to make you feel like a Skaia-chosen hero. The custom Pillars and Paths system has a variety of custom abilities to choose from as your character levels up, helping you create a hero with the powers of your choice.

If these websites still exist at the time of reading, you may find the most recent version of the RPGStuck rules at https://reddit.com/r/rpgstuck or https://discord.gg/rpgstuck. Our official YouTube channel is at https://youtube.com/rpgstuck.

## Instructions

The starting document is 3e-primer.pdf. The Session Master's Assistant, a helpful guide to running an RPGStuck session of your own, can be found in 3e-sm-assistant.pdf. All other .pdf documents are indexes of powers your character may have; these should be consulted over the course of your session when the primer references them.

### Character Sheet

The character sheet is located in 3e-character-sheet.xlsx. Opening a random Excel file from the internet is usually a bad idea. If you don't trust us, upload it to Google Docs or a similar online spreadsheet editor, and it should be useable. This system is playable without our character sheet; you can make your own, but ours has dropdown auto-filled menus for every feature imaginable.

## License

Homestuck is property of Andrew Hussie and the Homestuck Independent Creative Union. RPGStuck is created by the RPGStuck Development Team. The text of the RPGStuck ruleset is licensed under the Creative Commmons Attribution-NonCommercial-ShareAlike 4.0 license.