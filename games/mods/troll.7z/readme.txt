Last known good version: Enraged Koala
How to install:
Simply put "troll.modpak" inside the mods folder. With the latest (3/3/14) update, you no longer need to create folders to put mods in, since they now are a single modpak file. Putting them anywhere other than the raw "mods" folder will simply cause the mod not to load.

Have fun!

Special thanks to Kawa for helping me out starting with this mod.
Credits:
Alucard I
ML_Triforce (for most of the original shirts)
Chibi Banana (did most of the hair styles, redglare costume and some other things.)
Jewasaurus (originally made items for his mod, since he's no longer working on it he's offered me to include his files on mine.)
Arcane Music (one of the hammers is based off of his)
eLe (revamped the shirts, respawn animations and a bunch of cool stuff)


Want to help? Send me a PM over the Starbound forums.