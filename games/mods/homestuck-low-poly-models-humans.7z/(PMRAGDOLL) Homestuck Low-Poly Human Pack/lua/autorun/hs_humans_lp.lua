--Beta Kids

player_manager.AddValidModel( "John Egbert (Low Poly)", "models/player/hs_beta/john_lp.mdl" )
player_manager.AddValidHands( "John Egbert (Low Poly)", "models/player/hs_beta/c_arms_john_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Jade Harley (Low Poly)", "models/player/hs_beta/jade_lp.mdl" )
player_manager.AddValidHands( "Jade Harley (Low Poly)", "models/player/hs_beta/c_arms_jade_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Jade Bot (Low Poly)", "models/player/hs_beta/jade_bot_lp.mdl" )
player_manager.AddValidHands( "Jade Bot (Low Poly)", "models/player/hs_beta/c_arms_jade_bot_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Dave Strider (Low Poly)", "models/player/hs_beta/dave_lp.mdl" )
player_manager.AddValidHands( "Dave Strider (Low Poly)", "models/player/hs_beta/c_arms_dave_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Rose Lalonde (Low Poly)", "models/player/hs_beta/rose_lp.mdl" )
player_manager.AddValidHands( "Rose Lalonde (Low Poly)", "models/player/hs_beta/c_arms_rose_lp.mdl", 0, "0000000" )

-- Alpha Kids

player_manager.AddValidModel( "Jake English (Low Poly)", "models/player/hs_alpha/jake_lp.mdl" )
player_manager.AddValidHands( "Jake English (Low Poly)", "models/player/hs_alpha/c_arms_jake_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Jane Crocker (Low Poly)", "models/player/hs_alpha/jane_lp.mdl" )
player_manager.AddValidHands( "Jane Crocker (Low Poly)", "models/player/hs_alpha/c_arms_jane_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Dirk Strider (Low Poly)", "models/player/hs_alpha/dirk_lp.mdl" )
player_manager.AddValidHands( "Dirk Strider (Low Poly)", "models/player/hs_alpha/c_arms_dirk_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Dirk Bot (Low Poly)", "models/player/hs_alpha/dirk_bot_lp.mdl" )
player_manager.AddValidHands( "Dirk Bot (Low Poly)", "models/player/hs_alpha/c_arms_dirk_bot_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Roxy Lalonde (Low Poly)", "models/player/hs_alpha/roxy_lp.mdl" )
player_manager.AddValidHands( "Roxy Lalonde (Low Poly)", "models/player/hs_alpha/c_arms_roxy_lp.mdl", 0, "0000000" )

--Hiveswap Kids

player_manager.AddValidModel( "Joey Claire (Low Poly)", "models/player/hiveswap/joey_LP.mdl" )
player_manager.AddValidHands( "Joey Claire (Low Poly)", "models/player/hiveswap/c_arms_joey_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Jude Harley (Low Poly)", "models/player/hiveswap/jude_LP.mdl" )
player_manager.AddValidHands( "Jude Harley (Low Poly)", "models/player/hiveswap/c_arms_jude_lp.mdl", 0, "0000000" )

--Guardians

player_manager.AddValidModel( "Dad Egbert (Low Poly)", "models/player/hs_guardians/Dad_Egbert_LP.mdl" )
player_manager.AddValidHands( "Dad Egbert (Low Poly)", "models/player/hs_guardians/c_arms_dad_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Mom Lalonde (Low Poly)", "models/player/hs_guardians/Mom_Lalonde_LP.mdl" )
player_manager.AddValidHands( "Mom Lalonde (Low Poly)", "models/player/hs_guardians/c_arms_mom_lp.mdl", 0, "0000000" )

player_manager.AddValidModel( "Bro Strider (Low Poly)", "models/player/hs_guardians/Bro_Strider_LP.mdl" )
player_manager.AddValidHands( "Bro Strider (Low Poly)", "models/player/hs_guardians/c_arms_bro_lp.mdl", 0, "0000000" )