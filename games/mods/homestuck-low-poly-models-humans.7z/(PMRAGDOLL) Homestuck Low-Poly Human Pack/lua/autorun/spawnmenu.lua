--This lua file was made with "Physics_Dude's GMod Spawnlist Generator for .mdl's" 
if SERVER then
else
	local rootIcon = "hs_icons/logo.png"
	local rootTitle = "Homestuck Low-Poly Humans"
	local models = {
	
		["Beta Kids"] = {
			"models/player/hs_beta/john_lp.mdl",
			"models/player/hs_beta/rose_lp.mdl",
			"models/player/hs_beta/dave_lp.mdl",
			"models/player/hs_beta/jade_lp.mdl",
			"models/player/hs_beta/jade_bot_lp.mdl",
		},
		
		["Alpha Kids"] = {
			"models/player/hs_alpha/jane_lp.mdl",
			"models/player/hs_alpha/roxy_lp.mdl",
			"models/player/hs_alpha/dirk_lp.mdl",
			"models/player/hs_alpha/dirk_bot_lp.mdl",
			"models/player/hs_alpha/jake_lp.mdl",
		},
		
		["Guardians"] = {
			"models/player/hs_guardians/dad_egbert_lp.mdl",
			"models/player/hs_guardians/mom_lalonde_lp.mdl",
			"models/player/hs_guardians/bro_strider_lp.mdl",
		},
		
		
		["Hiveswap Kids"] = {
			"models/player/hiveswap/joey_LP.mdl",
			"models/player/hiveswap/jude_LP.mdl",
		},
		
	}

	hook.Add("PopulateContent", rootTitle, function(pnlContent, tree)

		local RootNode = tree:AddNode(rootTitle, rootIcon)

		local ViewPanel = vgui.Create("ContentContainer", pnlContent)
		ViewPanel:SetVisible(false)
		
		RootNode.DoClick = function()
		
			ViewPanel:Clear(true)
			
			for name, tbl in SortedPairs(models) do
			
				local label = vgui.Create("ContentHeader", container)
				label:SetText(name)

				ViewPanel:Add(label)
			
				for _, v in ipairs(tbl) do
				
					local mdlicon = spawnmenu.GetContentType("model")
					if mdlicon then
						mdlicon(ViewPanel, {model = v})
					end

				end
				
			end
			
			pnlContent:SwitchPanel(ViewPanel)
			
		end

	end)
	
end
