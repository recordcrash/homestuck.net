Installation:

Download 7zip here: https://www.7-zip.org/download.html

Navigate to the directory of your `Balatro.exe` file (typically it's `C:\Program Files (x86)\Steam\steamapps\common\Balatro`)

Open the `Balatro.exe` file using 7zip (typically it's `right click ==> 7zip ==> Open Archive`)

Drag and drop the `resource` folder into the root directory of `Balatro.exe`

And that's it!